import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Navigation from './sections/Navigation';
import HeroSection from './sections/HeroSection';
import FeatureCollage from './sections/FeatureCollage';
import WhyHeatPumps from './sections/WhyHeatPumps';
import Applications from './sections/Applications';
import HowItWorks from './sections/HowItWorks';
import CustomEngineering from './sections/CustomEngineering';
import EnergySavings from './sections/EnergySavings';
import Reliability from './sections/Reliability';
import GetQuote from './sections/GetQuote';
import Resources from './sections/Resources';
import About from './sections/About';
import Contact from './sections/Contact';
import Footer from './sections/Footer';

gsap.registerPlugin(ScrollTrigger);

function App() {
  const mainRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Wait for all sections to mount before setting up global snap
    const timer = setTimeout(() => {
      const pinned = ScrollTrigger.getAll()
        .filter(st => st.vars.pin)
        .sort((a, b) => a.start - b.start);
      
      const maxScroll = ScrollTrigger.maxScroll(window);
      
      if (!maxScroll || pinned.length === 0) return;

      const pinnedRanges = pinned.map(st => ({
        start: st.start / maxScroll,
        end: (st.end ?? st.start) / maxScroll,
        center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
      }));

      ScrollTrigger.create({
        snap: {
          snapTo: (value: number) => {
            const inPinned = pinnedRanges.some(
              r => value >= r.start - 0.02 && value <= r.end + 0.02
            );
            if (!inPinned) return value;

            const target = pinnedRanges.reduce(
              (closest, r) =>
                Math.abs(r.center - value) < Math.abs(closest - value)
                  ? r.center
                  : closest,
              pinnedRanges[0]?.center ?? 0
            );
            return target;
          },
          duration: { min: 0.15, max: 0.35 },
          delay: 0,
          ease: 'power2.out',
        },
      });
    }, 500);

    return () => {
      clearTimeout(timer);
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, []);

  return (
    <div ref={mainRef} className="relative bg-navy-primary">
      {/* Noise overlay */}
      <div className="noise-overlay" />
      
      {/* Navigation */}
      <Navigation />
      
      {/* Main content */}
      <main className="relative">
        {/* Section 1: Hero - z-10 */}
        <div className="relative z-10">
          <HeroSection />
        </div>
        
        {/* Section 2: Feature Collage - z-20 */}
        <div className="relative z-20">
          <FeatureCollage />
        </div>
        
        {/* Section 3: Why Heat Pumps - z-30 */}
        <div className="relative z-30">
          <WhyHeatPumps />
        </div>
        
        {/* Section 4: Applications - z-40 */}
        <div className="relative z-40">
          <Applications />
        </div>
        
        {/* Section 5: How It Works - z-50 */}
        <div className="relative z-50">
          <HowItWorks />
        </div>
        
        {/* Section 6: Custom Engineering - z-[60] */}
        <div className="relative z-[60]">
          <CustomEngineering />
        </div>
        
        {/* Section 7: Energy Savings - z-[70] */}
        <div className="relative z-[70]">
          <EnergySavings />
        </div>
        
        {/* Section 8: Reliability - z-[80] */}
        <div className="relative z-[80]">
          <Reliability />
        </div>
        
        {/* Section 9: Get Quote - z-[90] */}
        <div className="relative z-[90]">
          <GetQuote />
        </div>
        
        {/* Flowing sections */}
        <Resources />
        <About />
        <Contact />
        <Footer />
      </main>
    </div>
  );
}

export default App;
