import { Shield, FileCheck, Award } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const certifications = [
    { icon: Shield, label: 'ISO 9001' },
    { icon: FileCheck, label: 'CE Certified' },
    { icon: Award, label: 'AHRI Rated' },
  ];

  return (
    <footer className="relative py-12 lg:py-16 border-t border-white/5" style={{ backgroundColor: '#0B0F17' }}>
      <div className="w-full px-6 lg:px-[6vw]">
        {/* Certifications */}
        <div className="flex items-center justify-center gap-8 mb-8">
          {certifications.map((cert, index) => (
            <div key={index} className="flex items-center gap-2 text-secondary-light">
              <cert.icon className="w-5 h-5 text-[#F36B24]" />
              <span className="font-mono-label">{cert.label}</span>
            </div>
          ))}
        </div>

        {/* Main Footer Content */}
        <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
          {/* Logo */}
          <div className="font-display font-bold text-xl text-primary-light">
            MECHWORLD
          </div>

          {/* Links */}
          <div className="flex items-center gap-6">
            <a href="#" className="font-mono-label text-secondary-light hover:text-primary-light transition-colors">
              Privacy
            </a>
            <a href="#" className="font-mono-label text-secondary-light hover:text-primary-light transition-colors">
              Terms
            </a>
            <a href="#" className="font-mono-label text-secondary-light hover:text-primary-light transition-colors">
              Certifications
            </a>
          </div>

          {/* Copyright */}
          <div className="text-sm text-secondary-light">
            © {currentYear} MechWorld Eco Heat Pumps. All rights reserved.
          </div>
        </div>

        {/* Trust Badges */}
        <div className="mt-8 pt-8 border-t border-white/5 text-center">
          <p className="text-xs text-secondary-light/60 max-w-2xl mx-auto">
            Industrial-grade heat pumps for large-scale water heating. Replace fossil fuel boilers with electric heat pumps—reduce energy costs by up to 70% with 24/7 industrial-duty reliability.
          </p>
        </div>
      </div>
    </footer>
  );
}
