import { useState, useEffect } from 'react';
import { Menu, X, Phone } from 'lucide-react';

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Products', href: '#products' },
    { label: 'Applications', href: '#applications' },
    { label: 'Savings', href: '#savings' },
    { label: 'Contact', href: '#contact' },
  ];

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-[100] transition-all duration-300 ${
          isScrolled
            ? 'bg-[#0B0F17]/90 backdrop-blur-lg border-b border-white/5'
            : 'bg-transparent'
        }`}
      >
        <div className="w-full px-6 lg:px-12">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <a href="#" className="font-display font-bold text-xl lg:text-2xl text-primary-light tracking-tight">
              MECHWORLD
            </a>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-8">
              {navLinks.map((link) => (
                <button
                  key={link.label}
                  onClick={() => scrollToSection(link.href)}
                  className="text-sm font-medium text-secondary-light hover:text-primary-light transition-colors"
                >
                  {link.label}
                </button>
              ))}
            </div>

            {/* Desktop CTA */}
            <div className="hidden lg:flex items-center gap-4">
              <a
                href="tel:+15550142082"
                className="flex items-center gap-2 text-sm text-secondary-light hover:text-primary-light transition-colors"
              >
                <Phone className="w-4 h-4" />
                <span>+1 (555) 014-2082</span>
              </a>
              <button
                onClick={() => scrollToSection('#quote')}
                className="btn-primary"
              >
                Request a quote
              </button>
            </div>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-primary-light"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-[99] bg-[#0B0F17]/98 backdrop-blur-lg lg:hidden">
          <div className="flex flex-col items-center justify-center h-full gap-8">
            {navLinks.map((link) => (
              <button
                key={link.label}
                onClick={() => scrollToSection(link.href)}
                className="text-2xl font-display font-semibold text-primary-light hover:text-[#F36B24] transition-colors"
              >
                {link.label}
              </button>
            ))}
            <a
              href="tel:+15550142082"
              className="flex items-center gap-2 text-lg text-secondary-light mt-4"
            >
              <Phone className="w-5 h-5" />
              <span>+1 (555) 014-2082</span>
            </a>
            <button
              onClick={() => scrollToSection('#quote')}
              className="btn-primary mt-4"
            >
              Request a quote
            </button>
          </div>
        </div>
      )}
    </>
  );
}
